package empresa;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;
import java.math.RoundingMode;
public class Empresa {
    public static void main(String[] args) {
        try {
            int N = Integer.parseInt(JOptionPane.showInputDialog("¿Cuántas veces desea realizar el programa?"));
            if (N <= 0) {
                JOptionPane.showMessageDialog(null, "El número debe ser mayor que 0.");
                return;
            }
            DecimalFormat df = new DecimalFormat("#0.00"); 
            df.setRoundingMode(RoundingMode.HALF_UP);
            StringBuilder salida = new StringBuilder("Resumen de salarios:\n");
            for (int i = 1; i <= N; i++) {
                double horas = Double.parseDouble(JOptionPane.showInputDialog("[" + i + "/" + N + "] Horas trabajadas:"));
                double tasa  = Double.parseDouble(JOptionPane.showInputDialog("[" + i + "/" + N + "] Tasa por hora (Balboas):"));
                //Horas Extras
                double horasReg = Math.min(horas, 40.0);
                double horasExt = Math.max(0.0, horas - 40.0);
                //Cálculos
                double bruto = (horasReg * tasa) + (horasExt * tasa * 1.5);
                double impuesto = (bruto > 750.0) ? bruto * 0.10 : 0.0;
                double neto = bruto - impuesto;
                //Mostrar resultados
                String msgTrab = "Trabajador #" + i +
                        "\nHoras regulares: " + df.format(horasReg) +
                        "\nHoras extra:    " + df.format(horasExt) +
                        "\nBruto: B/. " + df.format(bruto) +
                        "\nImpuesto: B/. " + df.format(impuesto) +
                        "\nNeto:   B/. " + df.format(neto);
                JOptionPane.showMessageDialog(null, msgTrab);
                salida.append("Trabajador #").append(i)
                      .append(" Neto: B/. ").append(df.format(neto))
                      .append("\n");
            }
            JOptionPane.showMessageDialog(null, salida.toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Dato inválido.");
        }
    }
}
