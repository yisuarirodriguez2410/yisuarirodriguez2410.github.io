package parcial1;
import javax.swing.JOptionPane;

public class PARCIAL1 {
    public static void main(String[] args) {
       // Matriz para guardar 3 fechas
        int[][] fechas = new int[3][3]; 
        // Pedir las 3 fechas
        for (int i = 0; i < 3; i++) {
            int dia = Integer.parseInt(JOptionPane.showInputDialog("Día de la fecha #" + (i+1)));
            String mesTexto = JOptionPane.showInputDialog("Mes (ejemplo: febrero) de la fecha #" + (i+1));
            int anio = Integer.parseInt(JOptionPane.showInputDialog("Año de la fecha #" + (i+1)));
            int mes = 0;
            switch (mesTexto.toLowerCase()) {
                case "enero": mes = 1; break;
                case "febrero": mes = 2; break;
                case "marzo": mes = 3; break;
                case "abril": mes = 4; break;
                case "mayo": mes = 5; break;
                case "junio": mes = 6; break;
                case "julio": mes = 7; break;
                case "agosto": mes = 8; break;
                case "septiembre": mes = 9; break;
                case "octubre": mes = 10; break;
                case "noviembre": mes = 11; break;
                case "diciembre": mes = 12; break;
                default: JOptionPane.showMessageDialog(null, "Mes inválido"); break;
            }
            fechas[i][0] = dia;
            fechas[i][1] = mes;
            fechas[i][2] = anio;
        }
        String salida = "Fechas ingresadas:\n";
        for (int i = 0; i < 3; i++) {
            salida += fechas[i][0] + " " + fechas[i][1] + " " + fechas[i][2] + "\n";
        }
        int minIndex = 0, maxIndex = 0;
        for (int i = 1; i < 3; i++) {
            if ( (fechas[i][2] < fechas[minIndex][2]) || 
                (fechas[i][2] == fechas[minIndex][2] && fechas[i][1] < fechas[minIndex][1]) || 
                (fechas[i][2] == fechas[minIndex][2] && fechas[i][1] == fechas[minIndex][1] && fechas[i][0] < fechas[minIndex][0]) ) {
                minIndex = i;
            }
            if ( (fechas[i][2] > fechas[maxIndex][2]) || 
                (fechas[i][2] == fechas[maxIndex][2] && fechas[i][1] > fechas[maxIndex][1]) || 
                (fechas[i][2] == fechas[maxIndex][2] && fechas[i][1] == fechas[maxIndex][1] && fechas[i][0] > fechas[maxIndex][0]) ) {
                maxIndex = i;
            }
        }
        salida += "\nFecha más baja: " + fechas[minIndex][0] + " " + fechas[minIndex][1] + " " + fechas[minIndex][2];
        salida += "\nFecha más alta: " + fechas[maxIndex][0] + " " + fechas[maxIndex][1] + " " + fechas[maxIndex][2]; 
        JOptionPane.showMessageDialog(null, salida);  
    }
}
