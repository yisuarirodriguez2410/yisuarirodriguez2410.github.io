package fecha12;
import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.Period; 
import java.time.DateTimeException;

public class Fecha12 {
    public static void main(String[] args) {
        try {
            int N = Integer.parseInt(JOptionPane.showInputDialog("¿Cuántas edades quieres calcular?"));
            if (N <= 0) {
                JOptionPane.showMessageDialog(null, "El número debe ser mayor que 0.");
                return;
            }
            StringBuilder resumen = new StringBuilder("Resultados:\n");
            for (int i = 1; i <= N; i++) {
                // Ingreso de la fecha de nacimiento, validando que el formato sea el correcto
                LocalDate nacimiento = null;
                while (true) {
                    try {
                        int d_nac = Integer.parseInt(JOptionPane.showInputDialog("[" + i + "/" + N + "] Día de nacimiento (1-31):"));
                        int m_nac = Integer.parseInt(JOptionPane.showInputDialog("[" + i + "/" + N + "] Mes de nacimiento (1-12):"));
                        int a_nac = Integer.parseInt(JOptionPane.showInputDialog("[" + i + "/" + N + "] Año de nacimiento:"));
                        nacimiento = LocalDate.of(a_nac, m_nac, d_nac);
                        break;
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Ingresa números válidos (solo dígitos).");
                    } catch (DateTimeException e) {
                        JOptionPane.showMessageDialog(null, "Fecha de nacimiento inválida. Revisa día/mes/año.");
                    }
                }
                //Ingreso de la fecha actual, validando que no sea menor a la fecha de nacimiento
                LocalDate actual = null;
                while (true) {
                    try {
                        int d_act = Integer.parseInt(JOptionPane.showInputDialog("[" + i + "/" + N + "] Día actual (1-31):"));
                        int m_act = Integer.parseInt(JOptionPane.showInputDialog("[" + i + "/" + N + "] Mes actual (1-12):"));
                        int a_act = Integer.parseInt(JOptionPane.showInputDialog("[" + i + "/" + N + "] Año actual:"));
                        actual = LocalDate.of(a_act, m_act, d_act);
                        if (actual.isBefore(nacimiento)) {
                            JOptionPane.showMessageDialog(null, "La fecha actual no puede ser anterior al nacimiento.");
                            continue;
                        }
                        break;
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Ingresa números válidos (solo dígitos).");
                    } catch (DateTimeException e) {
                        JOptionPane.showMessageDialog(null, "Fecha actual inválida. Revisa día/mes/año.");
                    }
                }
                //Calcular la edad
                Period p = Period.between(nacimiento, actual);
                String msg;
                if (p.getYears() == 0) {
                    msg = "Edad: " + p.getMonths() + " mes(es) y " + p.getDays() + " día(s).";
                } else {
                    msg = "Edad: " + p.getYears() + " año(s).";
                }
                JOptionPane.showMessageDialog(null, "Persona #" + i + "\nNac.: " + nacimiento + "\nAct.: " + actual + "\n" + msg);
                resumen.append("Persona #").append(i).append(": ").append(msg).append("\n");
            }
            JOptionPane.showMessageDialog(null, resumen.toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Cancelado o dato inválido.");
        }   
        }
}
