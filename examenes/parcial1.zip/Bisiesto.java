package bisiesto;
import javax.swing.JOptionPane;
public class Bisiesto {
    public static void main(String[] args) {
     try {
            int N = Integer.parseInt(JOptionPane.showInputDialog("¿Cuántas veces desea realizar el programa?"));
            if (N <= 0) {
                JOptionPane.showMessageDialog(null, "El número debe ser mayor que 0.");
                return;
            }
            StringBuilder salida = new StringBuilder("Resultados:\n");
            for (int i = 1; i <= N; i++) {
                int ans = Integer.parseInt(JOptionPane.showInputDialog("Introduce el año #" + i + ":"));
                boolean es_bisiesto;
                if (ans % 4 == 0) {
                    if (ans % 100 == 0) {
                        es_bisiesto = (ans % 400 == 0);
                    } else {
                        es_bisiesto = true;
                    }
                } else {
                    es_bisiesto = false;
                }
                salida.append("Año ").append(ans).append(": ");
                salida.append(es_bisiesto ? "Es bisiesto" : "No es bisiesto").append("\n");
            }
            JOptionPane.showMessageDialog(null, salida.toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error: Ingresa un número válido.");
        }
    }
}
