package Vista;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class conexion {
    static String url ="jdbc:mysql://localhost:3306/NIBARRA?serverTimezone=America/Panama";
    static String user ="root";
    static String pass = "Yisu@2410";
    public static Connection conectar() {
        Connection con=null;
        if (con != null) return con;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection(url,user,pass);
            System.out.println("Conexión exitosa a MySQL: ");
        } catch (ClassNotFoundException e) {
            System.err.println("Error: driver JDBC no encontrado. " + e.getMessage());
            con = null;
        } catch (SQLException e) {
            System.err.println("Error al conectar con MySQL: " + e.getMessage());
            con = null;
        }
        return con;
    }
}
