package Vista;
import java.util.*;
import com.toedter.calendar.JCalendar;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;


public class Sistema extends javax.swing.JFrame {
    Map<String, String> respuestas = new HashMap<>();
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Sistema.class.getName());
    public Sistema() {
        initComponents();
        // Respuestas iniciales del chatbot
        respuestas.put("hola", "¡Hola! Soy el asistente virtual de NIBARRA");
        respuestas.put("cómo estás", "¡Estoy muy bien! Gracias por preguntar");
        respuestas.put("quién eres", "Soy un asistente creado en Java para ayudarte dentro del sistema NIBARRA.");
        respuestas.put("qué puedes hacer", "Puedo responderte dudas sobre el sistema, fechas, o darte información general.");
        respuestas.put("fecha", "Hoy es " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + ".");
        respuestas.put("ayuda", "Puedes preguntarme sobre usuarios, equipos, mantenimiento o cualquier duda general.");
        respuestas.put("adiós", "¡Hasta pronto!");
        respuestas.put("gracias", "¡Con gusto!");

        tablaMantenimiento.getSelectionModel().addListSelectionListener(e -> {
    int fila = tablaMantenimiento.getSelectedRow();
    if (fila >= 0) {
        int avance = Integer.parseInt(tablaMantenimiento.getValueAt(fila, 6).toString());
        barraProgreso.setValue(avance);
        barraProgreso.setStringPainted(true);
    }
});

        cmbServicio.removeAllItems();
        cmbServicio.addItem("Todos");
        cmbServicio.addItem("Predictivo");
        cmbServicio.addItem("Preventivo");
        cmbServicio.addItem("Correctivo");


        cmbMes.removeAllItems();
            String[] meses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
                    for (String mes : meses) {
                    cmbMes.addItem(mes);
            }

        // Llenar combo de años (por ejemplo desde 2020 hasta el año actual)
        cmbAnio.removeAllItems();
        int anioActual = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
        for (int i = 2020; i <= anioActual; i++) {
     cmbAnio.addItem(String.valueOf(i));
        }

        tablaEquipos.getSelectionModel().addListSelectionListener(new javax.swing.event.ListSelectionListener() {
    @Override
    public void valueChanged(javax.swing.event.ListSelectionEvent e) {
        int fila = tablaEquipos.getSelectedRow();
        if (fila >= 0) { // si hay fila seleccionada
            txtNIngreso.setText(tablaEquipos.getValueAt(fila, 0).toString());
            dateIngreso.setDate((java.util.Date) tablaEquipos.getValueAt(fila, 1));
            txtEquipo.setText(tablaEquipos.getValueAt(fila, 2).toString());
            txtMarca.setText(tablaEquipos.getValueAt(fila, 3).toString());
            txtSerie.setText(tablaEquipos.getValueAt(fila, 4).toString());
            txtServicio.setText(tablaEquipos.getValueAt(fila, 5).toString());
            
            // Fecha salida puede ser null
            Object fechaSalidaObj = tablaEquipos.getValueAt(fila, 6);
            if (fechaSalidaObj != null) {
                dateSalida.setDate((java.util.Date) fechaSalidaObj);
            } else {
                dateSalida.setDate(null);
            }
            
            txtCinicial.setText(tablaEquipos.getValueAt(fila, 7).toString());
            txtCtotal.setText(tablaEquipos.getValueAt(fila, 8).toString());
            cmbEstado.setSelectedItem(tablaEquipos.getValueAt(fila, 9).toString());
            txtObservaciones.setText(tablaEquipos.getValueAt(fila, 10).toString());
        }
    }
});
        cargarTabla();
        cargarCalendario();
        cargarMantenimiento("Todos", null, null);
        
    }
public void cargarTabla() {
    // Crear un modelo de tabla
    javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel();
    // Nombres de las columnas según tu tabla
    modelo.addColumn("ID");
    modelo.addColumn("Fecha Ingreso");
    modelo.addColumn("Equipo");
    modelo.addColumn("Marca");
    modelo.addColumn("Serie");
    modelo.addColumn("Tipo Servicio");
    modelo.addColumn("Fecha Salida");
    modelo.addColumn("Costo Inicial");
    modelo.addColumn("Costo Final");
    modelo.addColumn("Estado");
    modelo.addColumn("Observaciones");
    // Asignar modelo a la tabla
    tablaEquipos.setModel(modelo);
    // Conectar a la base de datos
    Connection con = conexion.conectar();
    if (con != null) {
        try {
            java.sql.Statement st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery("SELECT * FROM IngresoEquipos");
            
            while (rs.next()) {
                // Crear fila con los datos de MySQL
                Object[] fila = new Object[11];
                fila[0] = rs.getInt("idIngreso");
                fila[1] = rs.getDate("fechaIngreso");
                fila[2] = rs.getString("equipo");
                fila[3] = rs.getString("marca");
                fila[4] = rs.getString("serie");
                fila[5] = rs.getString("tipoServicio");
                fila[6] = rs.getDate("fechaSalida");
                fila[7] = rs.getDouble("costoInicial");
                fila[8] = rs.getDouble("costoFinal");
                fila[9] = rs.getString("estado");
                fila[10] = rs.getString("observaciones");
                
                modelo.addRow(fila);
            }
            
            rs.close();
            st.close();
            con.close();
            
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Error al cargar tabla: " + e.getMessage());
        }
    }
}
public void cargarCalendario() {
    try {
        Connection con = conexion.conectar();
        String sql = "SELECT idIngreso, equipo, fechaIngreso, fechaSalida, estado FROM IngresoEquipos";
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(sql);

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("N° Ingreso");
        modelo.addColumn("Equipo");
        modelo.addColumn("Fecha Ingreso");
        modelo.addColumn("Fecha Salida");
        modelo.addColumn("Estado");

        while (rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("idIngreso"),
                rs.getString("equipo"),
                rs.getDate("fechaIngreso"),
                rs.getDate("fechaSalida"),
                rs.getString("estado")
            });
        }

        tablaCalendario.setModel(modelo);
        rs.close();
        st.close();
        con.close();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al cargar calendario: " + e.getMessage());
    }
}
public void filtrarPorMes(int mes, int anio)
{
    try {
        Connection con = conexion.conectar();
        String sql = "SELECT idIngreso, equipo, fechaIngreso, fechaSalida, estado " +
                     "FROM IngresoEquipos WHERE (MONTH(fechaIngreso)=? AND YEAR(fechaIngreso)=?) " +
                     "OR (MONTH(fechaSalida)=? AND YEAR(fechaSalida)=?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, mes);
        ps.setInt(2, anio);
        ps.setInt(3, mes);
        ps.setInt(4, anio);
        ResultSet rs = ps.executeQuery();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("N° Ingreso");
        modelo.addColumn("Equipo");
        modelo.addColumn("Fecha Ingreso");
        modelo.addColumn("Fecha Salida");
        modelo.addColumn("Estado");

        while (rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("idIngreso"),
                rs.getString("equipo"),
                rs.getDate("fechaIngreso"),
                rs.getDate("fechaSalida"),
                rs.getString("estado")
            });
        }

        tablaCalendario.setModel(modelo);

        rs.close();
        ps.close();
        con.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al filtrar calendario: " + e.getMessage());
    }
}
public void cargarMantenimiento(String tipoServicio, java.util.Date inicio, java.util.Date fin) {
    try {
        Connection con = conexion.conectar();
        StringBuilder sql = new StringBuilder(
            "SELECT idIngreso, equipo, tipoServicio, estado, fechaIngreso, fechaSalida FROM IngresoEquipos WHERE 1=1"
        );

        // Filtros dinámicos
        if (!tipoServicio.equals("Todos")) {
            sql.append(" AND tipoServicio = ?");
        }
        if (inicio != null && fin != null) {
            sql.append(" AND (fechaIngreso BETWEEN ? AND ? OR fechaSalida BETWEEN ? AND ?)");
        }

        PreparedStatement ps = con.prepareStatement(sql.toString());

        int index = 1;
        if (!tipoServicio.equals("Todos")) {
            ps.setString(index++, tipoServicio);
        }
        if (inicio != null && fin != null) {
            java.sql.Date sqlInicio = new java.sql.Date(inicio.getTime());
            java.sql.Date sqlFin = new java.sql.Date(fin.getTime());
            ps.setDate(index++, sqlInicio);
            ps.setDate(index++, sqlFin);
            ps.setDate(index++, sqlInicio);
            ps.setDate(index++, sqlFin);
        }

        ResultSet rs = ps.executeQuery();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("N° Ingreso");
        modelo.addColumn("Equipo");
        modelo.addColumn("Tipo Servicio");
        modelo.addColumn("Estado");
        modelo.addColumn("Fecha Ingreso");
        modelo.addColumn("Fecha Salida");
        modelo.addColumn("Avance (%)");

        while (rs.next()) {
            String estado = rs.getString("estado");
            int avance = calcularAvance(estado);

            modelo.addRow(new Object[]{
                rs.getInt("idIngreso"),
                rs.getString("equipo"),
                rs.getString("tipoServicio"),
                estado,
                rs.getDate("fechaIngreso"),
                rs.getDate("fechaSalida"),
                avance
            });
        }

        tablaMantenimiento.setModel(modelo);

        rs.close();
        ps.close();
        con.close();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al cargar mantenimiento: " + e.getMessage());
    }
}
private int calcularAvance(String estado) {
    switch (estado.toLowerCase()) {
        case "por hacer":
            return 0;
        case "en espera de material":
            return 25;
        case "en revisión":
            return 60;
        case "terminada":
            return 100;
        default:
            return 0;
    }
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        barraProgreso = new javax.swing.JProgressBar();
        jLabel1 = new javax.swing.JLabel();
        tabSistema = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaEquipos = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtNIngreso = new javax.swing.JTextField();
        txtEquipo = new javax.swing.JTextField();
        txtMarca = new javax.swing.JTextField();
        txtServicio = new javax.swing.JTextField();
        txtCtotal = new javax.swing.JTextField();
        txtSerie = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtObservaciones = new javax.swing.JTextField();
        txtCinicial = new javax.swing.JTextField();
        cmbEstado = new javax.swing.JComboBox<>();
        dateSalida = new com.toedter.calendar.JDateChooser();
        dateIngreso = new com.toedter.calendar.JDateChooser();
        btnIngresar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablaCalendario = new javax.swing.JTable();
        cmbMes = new javax.swing.JComboBox<>();
        cmbAnio = new javax.swing.JComboBox<>();
        btnFiltrar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtUsu = new javax.swing.JTextField();
        txtContra = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        cmbServicio = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        dateInicio = new com.toedter.calendar.JDateChooser();
        dateFin = new com.toedter.calendar.JDateChooser();
        btnFil = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaMantenimiento = new javax.swing.JTable();
        btnActualizarAvance = new javax.swing.JButton();
        txtChat = new javax.swing.JTextArea();
        jPanel5 = new javax.swing.JPanel();
        btnEnviar = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        txtMensaje = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtCha = new javax.swing.JTextArea();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Encabezado.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1270, 140));

        tablaEquipos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tablaEquipos);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel2.setText("N° Ingreso:");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel3.setText("Fecha de Ingreso:");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel4.setText("Equipo:");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel5.setText("Marca:");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel6.setText("Serie:");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel7.setText("Tipo de Servicio:");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel8.setText("Costo Inicial: ");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel9.setText("Fecha de Salida:");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel10.setText("Observaciones: ");

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel11.setText("Estado: ");

        txtNIngreso.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

        txtEquipo.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

        txtMarca.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

        txtServicio.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

        txtCtotal.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

        txtSerie.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel12.setText("Costo Total: ");

        txtObservaciones.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

        txtCinicial.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

        cmbEstado.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Por Hacer", "En Espera de Material", "En Revisión", "Terminado" }));

        btnIngresar.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btnIngresar.setText("INGRESAR");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnActualizar.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btnActualizar.setText("ACTUALIZAR");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnLimpiar.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(2, 2, 2)
                                .addComponent(txtMarca))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtSerie, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtEquipo))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dateIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtNIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnIngresar)
                                .addGap(18, 18, 18)
                                .addComponent(btnEliminar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnActualizar)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel7))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(6, 6, 6)
                                                .addComponent(dateSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(txtServicio, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtCtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel10)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtCinicial, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(114, 114, 114)
                                        .addComponent(txtObservaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(100, 100, 100))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(btnBuscar)
                                .addGap(35, 35, 35)
                                .addComponent(btnLimpiar)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel7)
                    .addComponent(txtNIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtServicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jLabel9))
                    .addComponent(dateSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel8)
                    .addComponent(txtEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCinicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(txtCtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel10)
                    .addComponent(txtSerie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtObservaciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnIngresar)
                        .addComponent(btnEliminar))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnActualizar)
                        .addComponent(btnLimpiar)
                        .addComponent(btnBuscar)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabSistema.addTab("Tabla Equipos ", jPanel1);

        tablaCalendario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "N° de Ingreso", "Equipo", "Fecha de Ingreso", "Fecha de Salida", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane4.setViewportView(tablaCalendario);

        cmbMes.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        cmbMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Enero", "Febrero", "Marzo ", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre ", "Octubre ", "Noviembre ", "Diciembre" }));

        cmbAnio.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        cmbAnio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034" }));

        btnFiltrar.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        btnFiltrar.setText("Filtrar");
        btnFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane4)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(cmbMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(120, 120, 120)
                .addComponent(cmbAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(252, 252, 252)
                .addComponent(btnFiltrar)
                .addContainerGap(364, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(cmbMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnFiltrar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(102, Short.MAX_VALUE))
        );

        tabSistema.addTab("Calendario", jPanel2);

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel16.setText("Usuario:");

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel17.setText("Contraseña:");

        txtUsu.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        txtContra.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        txtContra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContraActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnAgregar.setText("AGREGAR NUEVO USUARIO");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtUsu, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnAgregar)
                            .addComponent(txtContra, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(622, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtUsu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(txtContra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addComponent(btnAgregar)
                .addContainerGap(413, Short.MAX_VALUE))
        );

        tabSistema.addTab("Usuarios", jPanel4);

        jLabel13.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel13.setText("Tipo de Servicio:");

        cmbServicio.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        cmbServicio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel14.setText("Desde: ");

        jLabel15.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel15.setText("Hasta:");

        btnFil.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnFil.setText("Filtrar");
        btnFil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilActionPerformed(evt);
            }
        });

        tablaMantenimiento.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tablaMantenimiento);

        btnActualizarAvance.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnActualizarAvance.setText("Actualizar");
        btnActualizarAvance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarAvanceActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmbServicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel15)
                                        .addGap(18, 18, 18)
                                        .addComponent(dateFin, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(dateInicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(104, 104, 104)
                                .addComponent(btnFil)
                                .addGap(96, 96, 96)
                                .addComponent(btnActualizarAvance))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 909, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbServicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dateInicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dateFin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnFil)
                            .addComponent(btnActualizarAvance))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        tabSistema.addTab("Mantenimiento", jPanel3);

        getContentPane().add(tabSistema, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 1050, 560));

        txtChat.setEditable(false);
        txtChat.setColumns(20);
        txtChat.setLineWrap(true);
        txtChat.setRows(5);
        txtChat.setWrapStyleWord(true);
        getContentPane().add(txtChat, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel5.setBackground(new java.awt.Color(255, 204, 204));

        btnEnviar.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        btnEnviar.setText("Enviar");
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel18.setText("¡Hable Con un ChatBot!");

        txtMensaje.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        txtCha.setEditable(false);
        txtCha.setColumns(20);
        txtCha.setLineWrap(true);
        txtCha.setRows(5);
        txtCha.setWrapStyleWord(true);
        jScrollPane5.setViewportView(txtCha);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jLabel18)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txtMensaje, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnEnviar))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEnviar)
                    .addComponent(txtMensaje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 450, 220, 250));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        // Conexión a la base de datos
    Connection con = conexion.conectar();
    
    if (con != null) {
        try {
            // Preparar la consulta SQL para insertar
            String sql = "INSERT INTO IngresoEquipos "
                       + "(idIngreso, fechaIngreso, equipo, marca, serie, tipoServicio, fechaSalida, costoInicial, costoFinal, estado, observaciones) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            java.sql.PreparedStatement ps = con.prepareStatement(sql);
            
            // Tomar valores de los campos del formulario
            int idIngreso = Integer.parseInt(txtNIngreso.getText());
            java.util.Date fechaIngreso = dateIngreso.getDate();
            java.util.Date fechaSalida = dateSalida.getDate(); 
            String equipo = txtEquipo.getText();
            String marca = txtMarca.getText();
            String serie = txtSerie.getText();
            String tipoServicio = txtServicio.getText();
            double costoInicial = Double.parseDouble(txtCinicial.getText());
            double costoFinal = Double.parseDouble(txtCtotal.getText());
            String estado = cmbEstado.getSelectedItem().toString();
            String observaciones = txtObservaciones.getText();
            
            // Convertir fechas a java.sql.Date
            java.sql.Date sqlFechaIngreso = new java.sql.Date(fechaIngreso.getTime());
            java.sql.Date sqlFechaSalida = (fechaSalida != null) ? new java.sql.Date(fechaSalida.getTime()) : null;
            
            // Asignar parámetros
            ps.setInt(1, idIngreso);
            ps.setDate(2, sqlFechaIngreso);
            ps.setString(3, equipo);
            ps.setString(4, marca);
            ps.setString(5, serie);
            ps.setString(6, tipoServicio);
            if (sqlFechaSalida != null) {
                ps.setDate(7, sqlFechaSalida);
            } else {
                ps.setNull(7, java.sql.Types.DATE);
            }
            ps.setDouble(8, costoInicial);
            ps.setDouble(9, costoFinal);
            ps.setString(10, estado);
            ps.setString(11, observaciones);
            
            // Ejecutar inserción
            int n = ps.executeUpdate();
            
            if (n > 0) {
                javax.swing.JOptionPane.showMessageDialog(null, "Ingreso registrado correctamente");
            }
            
            ps.close();
            con.close();
            
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Error al ingresar equipo: " + e.getMessage());
        }
    } else {
        javax.swing.JOptionPane.showMessageDialog(null, "No se pudo conectar a la base de datos");
    }
    }//GEN-LAST:event_btnIngresarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int filaSeleccionada = tablaEquipos.getSelectedRow();
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(null, "Debe seleccionar un registro para eliminar");
        return;
    }
    // Obtener el ID del registro desde la tabla
    int idIngreso = Integer.parseInt(tablaEquipos.getValueAt(filaSeleccionada, 0).toString());
    // Confirmar eliminación
    int confirm = javax.swing.JOptionPane.showConfirmDialog(null,
            "¿Está seguro de eliminar el registro seleccionado?", "Confirmar eliminación",
            javax.swing.JOptionPane.YES_NO_OPTION);
    if (confirm == javax.swing.JOptionPane.YES_OPTION) {
        Connection con = conexion.conectar();
        if (con != null) {
            try {
                String sql = "DELETE FROM IngresoEquipos WHERE idIngreso = ?";
                java.sql.PreparedStatement ps = con.prepareStatement(sql);
                ps.setInt(1, idIngreso);
                
                int n = ps.executeUpdate();
                
                if (n > 0) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Registro eliminado correctamente");
                    cargarTabla(); 
                }
                
                ps.close();
                con.close();
                
            } catch (Exception e) {
                javax.swing.JOptionPane.showMessageDialog(null, "Error al eliminar registro: " + e.getMessage());
            }
        }
    }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        int filaSeleccionada = tablaEquipos.getSelectedRow();
    
    if (filaSeleccionada == -1) {
        javax.swing.JOptionPane.showMessageDialog(null, "Debe seleccionar un registro para actualizar");
        return;
    }
    
    // Obtener el ID del registro desde la tabla (columna 0)
    int idIngreso = Integer.parseInt(tablaEquipos.getValueAt(filaSeleccionada, 0).toString());
    
    // Leer los datos de los campos del formulario
    try {
        java.util.Date fechaIngreso = dateIngreso.getDate();
        java.util.Date fechaSalida = dateSalida.getDate(); 
        String equipo = txtEquipo.getText();
        String marca = txtMarca.getText();
        String serie = txtSerie.getText();
        String tipoServicio = txtServicio.getText();
        double costoInicial = Double.parseDouble(txtCinicial.getText());
        double costoFinal = Double.parseDouble(txtCtotal.getText());
        String estado = cmbEstado.getSelectedItem().toString();
        String observaciones = txtObservaciones.getText();
        java.sql.Date sqlFechaIngreso = new java.sql.Date(fechaIngreso.getTime());
        java.sql.Date sqlFechaSalida = (fechaSalida != null) ? new java.sql.Date(fechaSalida.getTime()) : null;
        // Conectar y actualizar en BD
        Connection con = conexion.conectar();
        if (con != null) {
            String sql = "UPDATE IngresoEquipos SET fechaIngreso=?, equipo=?, marca=?, serie=?, tipoServicio=?, "
                       + "fechaSalida=?, costoInicial=?, costoFinal=?, estado=?, observaciones=? WHERE idIngreso=?";
            java.sql.PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, sqlFechaIngreso);
            ps.setString(2, equipo);
            ps.setString(3, marca);
            ps.setString(4, serie);
            ps.setString(5, tipoServicio);
            if (sqlFechaSalida != null) {
                ps.setDate(6, sqlFechaSalida);
            } else {
                ps.setNull(6, java.sql.Types.DATE);
            }
            
            ps.setDouble(7, costoInicial);
            ps.setDouble(8, costoFinal);
            ps.setString(9, estado);
            ps.setString(10, observaciones);
            ps.setInt(11, idIngreso);
            
            int n = ps.executeUpdate();
            if (n > 0) {
                javax.swing.JOptionPane.showMessageDialog(null, "Registro actualizado correctamente");
                cargarTabla(); 
            }
            
            ps.close();
            con.close();
        }
        
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(null, "Error al actualizar: " + e.getMessage());
    }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String idText = txtNIngreso.getText().trim();
    
    if (idText.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(null, "Ingrese un N° de Ingreso para buscar");
        return;
    }
    
    try {
        int idIngreso = Integer.parseInt(idText);
        
        // Crear un modelo para la tabla
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Fecha Ingreso");
        modelo.addColumn("Equipo");
        modelo.addColumn("Marca");
        modelo.addColumn("Serie");
        modelo.addColumn("Tipo Servicio");
        modelo.addColumn("Fecha Salida");
        modelo.addColumn("Costo Inicial");
        modelo.addColumn("Costo Final");
        modelo.addColumn("Estado");
        modelo.addColumn("Observaciones");
        
        // Conectar a la base de datos
        Connection con = conexion.conectar();
        if (con != null) {
            String sql = "SELECT * FROM IngresoEquipos WHERE idIngreso = ?";
            java.sql.PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idIngreso);
            
            java.sql.ResultSet rs = ps.executeQuery();
            
            boolean encontrado = false;
            while (rs.next()) {
                Object[] fila = new Object[11];
                fila[0] = rs.getInt("idIngreso");
                fila[1] = rs.getDate("fechaIngreso");
                fila[2] = rs.getString("equipo");
                fila[3] = rs.getString("marca");
                fila[4] = rs.getString("serie");
                fila[5] = rs.getString("tipoServicio");
                fila[6] = rs.getDate("fechaSalida");
                fila[7] = rs.getDouble("costoInicial");
                fila[8] = rs.getDouble("costoFinal");
                fila[9] = rs.getString("estado");
                fila[10] = rs.getString("observaciones");
                
                modelo.addRow(fila);
                encontrado = true;
            }
            
            tablaEquipos.setModel(modelo);
            
            if (!encontrado) {
                javax.swing.JOptionPane.showMessageDialog(null, "No se encontró registro con N° de Ingreso: " + idIngreso);
            }
            
            rs.close();
            ps.close();
            con.close();
        }
        
    } catch (NumberFormatException e) {
        javax.swing.JOptionPane.showMessageDialog(null, "Ingrese un número válido para N° de Ingreso");
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(null, "Error al buscar: " + e.getMessage());
    }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // Limpiar JTextFields
    txtNIngreso.setText("");
    txtEquipo.setText("");
    txtMarca.setText("");
    txtSerie.setText("");
    txtServicio.setText("");
    txtCinicial.setText("");
    txtCtotal.setText("");
    txtObservaciones.setText("");
    
    // Limpiar JDateChooser
    dateIngreso.setDate(null);
    dateSalida.setDate(null);
    
    // Resetear JComboBox
    cmbEstado.setSelectedIndex(0); 
    cargarTabla();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiltrarActionPerformed
         int mesSeleccionado = cmbMes.getSelectedIndex() + 1; 
         int anioSeleccionado = Integer.parseInt(cmbAnio.getSelectedItem().toString());
         filtrarPorMes(mesSeleccionado, anioSeleccionado);
    }//GEN-LAST:event_btnFiltrarActionPerformed

    private void btnFilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilActionPerformed
        String tipoServicio = cmbServicio.getSelectedItem().toString();
        java.util.Date inicio = dateInicio.getDate();
        java.util.Date fin = dateFin.getDate();
        cargarMantenimiento(tipoServicio, inicio, fin);
    }//GEN-LAST:event_btnFilActionPerformed

    private void btnActualizarAvanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarAvanceActionPerformed
        int fila = tablaMantenimiento.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Seleccione un equipo para actualizar.");
        return;
    }

    int idIngreso = Integer.parseInt(tablaMantenimiento.getValueAt(fila, 0).toString());
    String nuevoEstado = JOptionPane.showInputDialog("Ingrese nuevo estado (Por hacer / En espera de material / En revisión / Terminada):");

    try {
        Connection con = conexion.conectar();
        String sql = "UPDATE IngresoEquipos SET estado=? WHERE idIngreso=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, nuevoEstado);
        ps.setInt(2, idIngreso);
        ps.executeUpdate();
        ps.close();
        con.close();

        JOptionPane.showMessageDialog(null, "Estado actualizado correctamente.");

        // recargar tabla con el filtro actual
        String tipoServicio = cmbServicio.getSelectedItem().toString();
        java.util.Date inicio = dateInicio.getDate();
        java.util.Date fin = dateFin.getDate();
        cargarMantenimiento(tipoServicio, inicio, fin);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al actualizar estado: " + e.getMessage());
    }
    }//GEN-LAST:event_btnActualizarAvanceActionPerformed

    private void txtContraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContraActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
         String usuario = txtUsu.getText().trim();
         String password = txtContra.getText().trim();

    // Validar campos vacíos
    if (usuario.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Debe ingresar usuario y contraseña", "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }

    Connection con = conexion.conectar();
    if (con == null) {
        JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        // Primero, verificar si el usuario ya existe
        String checkSql = "SELECT * FROM usuarios WHERE usu = ?";
        PreparedStatement checkStmt = con.prepareStatement(checkSql);
        checkStmt.setString(1, usuario);
        ResultSet rs = checkStmt.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(this, "El usuario ya existe", "Duplicado", JOptionPane.WARNING_MESSAGE);
            txtUsu.requestFocus();
        } else {
            // Si no existe, insertarlo
            String insertSql = "INSERT INTO usuarios (usu, psword) VALUES (?, ?)";
            PreparedStatement insertStmt = con.prepareStatement(insertSql);
            insertStmt.setString(1, usuario);
            insertStmt.setString(2, password);

            int rows = insertStmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Usuario agregado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                txtUsu.setText("");
                txtContra.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo agregar el usuario", "Error", JOptionPane.ERROR_MESSAGE);
            }

            insertStmt.close();
        }

        rs.close();
        checkStmt.close();
        con.close();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al guardar el usuario: " + e.getMessage(), "Error SQL", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
         String mensaje = txtMensaje.getText().trim().toLowerCase();
    if (mensaje.isEmpty()) return;

    txtCha.append("Tú: " + mensaje + "\n");

    if (mensaje.startsWith("enseñar:")) {
        try {
            String[] partes = mensaje.replace("enseñar:", "").split("=");
            String pregunta = partes[0].trim();
            String respuestaNueva = partes[1].trim();
            respuestas.put(pregunta, respuestaNueva);
            txtCha.append("Bot: ¡He aprendido algo nuevo! 🧠\n\n");
        } catch (Exception e) {
            txtCha.append("Bot: Usa el formato correcto → enseñar: pregunta = respuesta\n\n");
        }
        txtMensaje.setText("");
        return;
    }

    // 2️⃣ Buscar respuesta automática
    String respuesta = "No estoy seguro de eso. Pero puedes preguntarme sobre usuarios, equipos o mantenimiento.";

    for (String clave : respuestas.keySet()) {
        if (mensaje.contains(clave)) {
            respuesta = respuestas.get(clave);
            break;
        }
    }

    txtCha.append("Bot: " + respuesta + "\n\n");
    txtMensaje.setText("");
    }//GEN-LAST:event_btnEnviarActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Sistema().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar barraProgreso;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnActualizarAvance;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnFil;
    private javax.swing.JButton btnFiltrar;
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<String> cmbAnio;
    private javax.swing.JComboBox<String> cmbEstado;
    private javax.swing.JComboBox<String> cmbMes;
    private javax.swing.JComboBox<String> cmbServicio;
    private com.toedter.calendar.JDateChooser dateFin;
    private com.toedter.calendar.JDateChooser dateIngreso;
    private com.toedter.calendar.JDateChooser dateInicio;
    private com.toedter.calendar.JDateChooser dateSalida;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTabbedPane tabSistema;
    private javax.swing.JTable tablaCalendario;
    private javax.swing.JTable tablaEquipos;
    private javax.swing.JTable tablaMantenimiento;
    private javax.swing.JTextArea txtCha;
    private javax.swing.JTextArea txtChat;
    private javax.swing.JTextField txtCinicial;
    private javax.swing.JTextField txtContra;
    private javax.swing.JTextField txtCtotal;
    private javax.swing.JTextField txtEquipo;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtMensaje;
    private javax.swing.JTextField txtNIngreso;
    private javax.swing.JTextField txtObservaciones;
    private javax.swing.JTextField txtSerie;
    private javax.swing.JTextField txtServicio;
    private javax.swing.JTextField txtUsu;
    // End of variables declaration//GEN-END:variables
}
