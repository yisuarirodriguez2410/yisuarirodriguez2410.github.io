package hipotenusa1;
import javax.swing.JOptionPane;
 
public class Hipotenusa1 {
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Variables
        double cate_1, cate_2, hipo;
        
        //Ingreso de datos 
        String  cate_11 = JOptionPane.showInputDialog (null, "Ingrese el primer cateto del Triángulo");
        cate_1 = Double.parseDouble(cate_11);
        String  cate_22 = JOptionPane.showInputDialog (null, "Ingrese el segundo cateto del Triángulo");
        cate_2 = Double.parseDouble(cate_22);
        //Operación 
        hipo = Math.sqrt((cate_1*cate_1) + (cate_2*cate_2));
        //Imprimir 
        
         String resultado = String.format("%.2f", hipo);
         JOptionPane.showMessageDialog(null, "La hipotenusa es: " + resultado);
    }
    
}
