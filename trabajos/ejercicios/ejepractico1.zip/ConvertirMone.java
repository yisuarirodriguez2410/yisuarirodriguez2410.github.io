package convertirmone;
import javax.swing.JOptionPane;

public class ConvertirMone {

    public static void main(String[] args) {
        // TODO code application logic here
        //variable 
        double dolar, euro, peseta, yen, lib_esterlina, fra_suizo,dolar_cana;
        
        //datos
        String  dolar1 = JOptionPane.showInputDialog (null, "Ingrese la cantidad de Dólares: ");
        dolar = Double.parseDouble(dolar1);
        //operaciones 
        euro = dolar * 0.86;
        peseta = dolar * 142.28;
        yen = dolar * 147.47;
        lib_esterlina = dolar * 0.74;
        fra_suizo = dolar * 0.80;
        dolar_cana = dolar * 1.39;
        //Imprimir
        JOptionPane.showMessageDialog(null,"$" +dolar+" En las siguientes monedas:"+ 
                "\n Euros: " + String.format("%.2f",euro)+ "\n Peseta: " + String.format("%.2f",peseta) + "\n Yen Japónes: " + String.format("%.2f",yen)
                + "\n Libra Esterlina: " + String.format("%.2f",lib_esterlina)+ "\n Franco Suizo: " + String.format("%.2f",fra_suizo)+ 
                "\n Dolár Canadiense: " + String.format("%.2f",dolar_cana));
        
                
    }
    
}
