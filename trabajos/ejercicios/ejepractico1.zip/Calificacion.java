package calificacion;
import javax.swing.JOptionPane;

public class Calificacion {

    public static void main(String[] args) {
      // TODO code application logic her
      // Nombre del estudiante
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del estudiante:");

        // Examen Final
        double examenFinal = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota del Examen Final (Proyecto):"));

        // Parciales
        double parcial1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota del Primer Parcial:"));
        double parcial2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota del Segundo Parcial:"));
        double parcial3 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota del Tercer Parcial:"));
        double promedioParciales = (parcial1 + parcial2 + parcial3) / 3;
 
        //Laboratorios
        double lab1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota del Primer Laboratorio:"));
        double lab2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota del Segundo Laboratorio:"));
        double promedioLabs = (lab1 + lab2) / 2;

        //Asignaciones
        double asig1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota de la Primera Asignación:"));
        double asig2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota de la Segunda Asignación:"));
        double promedioAsig = (asig1 + asig2) / 2;

        //Portafolio y asistencia
        double portafolio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota del Portafolio Digital:"));
        double asistencia = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la nota de Asistencia:"));

        //Cálculo
        double notaFinal = (examenFinal * 0.33) +
                           (promedioParciales * 0.30) +
                           (promedioLabs * 0.17) +
                           (promedioAsig * 0.10) +
                           (portafolio * 0.05) +
                           (asistencia * 0.05);

        //Resultados
        String resultado = "Estudiante: " + nombre +
                           "\nExamen Final (33%): " + String.format("%.2f", examenFinal * 0.33) +
                           "\nPromedio Parciales (30%): " + String.format("%.2f", promedioParciales * 0.30) +
                           "\nPromedio Laboratorios (17%): " + String.format("%.2f", promedioLabs * 0.17) +
                           "\nPromedio Asignaciones (10%): " + String.format("%.2f", promedioAsig * 0.10) +
                           "\nPortafolio Digital (5%): " + String.format("%.2f", portafolio * 0.05) +
                           "\nAsistencia (5%): " + String.format("%.2f", asistencia * 0.05) +
                           "\nNOTA FINAL: " + String.format("%.2f", notaFinal);

        JOptionPane.showMessageDialog(null, resultado);
    }
}

    
