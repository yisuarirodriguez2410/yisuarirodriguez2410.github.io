package letras12;
import javax.swing.JOptionPane;

public class Letras12 {

    public static void main(String[] args) {
        // TODO code application logic here}
        //variables 
        int letras;
        String lqmq, abecedario, let;
        abecedario = "abcdefghijklmnñopqrstuvwxyz";
        lqmq = "Yaribeth González";
        let = "";
        
        String letras1 = JOptionPane.showInputDialog (null, "Introduzca la cantidad de letras que quiere: ");
        letras = Integer.parseInt(letras1);
        //Condición
        if (letras>0 && letras<=abecedario.length()){
            let = abecedario.substring(0, letras);
        }else{
            let = abecedario;
        }
        //Imprimir 
        JOptionPane.showMessageDialog(null,"La persona que más quiero: " + lqmq + "\nY las letras son: " + let);
       
    }
    
}
