public class Porta {
    public static void main(String[] args) {

        System.out.println("UNIVERSIDAD TECNOLÓGICA DE PANAMÁ");
        System.out.println("FACULTAD DE INGENIERÍA DE SISTEMAS COMPUTACIONALES");
        System.out.println("LICENCIATURA EN CIBERSEGURIDAD");
        System.out.println();

        System.out.println("Programación I");
        System.out.println();
        System.out.println("LABORATORIO #1");
        System.out.println();

        System.out.println("PREPARADO POR:");
        System.out.println("Rodríguez, Yisuari 1-760-982");
        System.out.println();

        System.out.println("A CONSIDERACIÓN DE");
        System.out.println("Napoleón Ibarra");
        System.out.println();

        System.out.println("2S3111");
        System.out.println("20/08/2025");
        System.out.println();
    }
}
