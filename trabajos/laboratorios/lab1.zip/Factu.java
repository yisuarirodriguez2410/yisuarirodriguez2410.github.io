public class Factu {
    public static void main(String[] args) {
        System.out.println("   Distribuidora Candanedo, S.A");
        System.out.println("   Cliente: Yisuari Rodriguez");
        System.out.println("==================================");
        System.out.println("CANTIDAD  DESCRIPCION   UNITARIO   TOTAL");
        System.out.println("3         Jugos         12.50      37.5");
        System.out.println("4         Caramelos     5.25       21.0");
        System.out.println("5         Globos        3.75       18.75");
        System.out.println("----------------------------------");
        System.out.println("SUBTOTAL: 77.25");
        System.out.println("ITBMS 7%: 5.41");
        System.out.println("TOTAL A PAGAR: 82.66");
    }
}
