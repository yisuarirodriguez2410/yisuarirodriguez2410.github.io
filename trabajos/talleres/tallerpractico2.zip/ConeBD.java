package conebd;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ConeBD extends JFrame {

    private JTabbedPane pestañas;
    private DefaultTableModel modeloProv, modeloProd, modeloVentas, modeloFact;

    public ConeBD () {
        setTitle("Sistema María Pan - Gestión General");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        pestañas = new JTabbedPane();
        pestañas.addTab("Proveedores", crearPanelProveedores());
        pestañas.addTab("Productos", crearPanelProductos());
        pestañas.addTab("Ventas", crearPanelVentas());
        pestañas.addTab("Facturas", crearPanelFacturas());

        add(pestañas);
    }

    // PANEL PROVEEDORES
    private JPanel crearPanelProveedores() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);
        c.anchor = GridBagConstraints.WEST;

        JTextField txtId = new JTextField(5);
        JTextField txtNombre = new JTextField(15);
        JTextField txtTelefono = new JTextField(12);
        JTextField txtCorreo = new JTextField(20);
        txtId.setEditable(false);

        JButton btnGuardar = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        c.gridx = 0; c.gridy = 0; form.add(new JLabel("ID:"), c);
        c.gridx = 1; form.add(txtId, c);
        c.gridx = 0; c.gridy = 1; form.add(new JLabel("Nombre:"), c);
        c.gridx = 1; form.add(txtNombre, c);
        c.gridx = 0; c.gridy = 2; form.add(new JLabel("Teléfono:"), c);
        c.gridx = 1; form.add(txtTelefono, c);
        c.gridx = 0; c.gridy = 3; form.add(new JLabel("Correo:"), c);
        c.gridx = 1; form.add(txtCorreo, c);

        JPanel botones = new JPanel();
        botones.add(btnGuardar); botones.add(btnActualizar);
        botones.add(btnEliminar); botones.add(btnLimpiar);
        c.gridx = 0; c.gridy = 4; c.gridwidth = 2; form.add(botones, c);

        modeloProv = new DefaultTableModel(new String[]{"ID","Nombre","Teléfono","Correo"}, 0);
        JTable tabla = new JTable(modeloProv);
        JScrollPane scroll = new JScrollPane(tabla);
        panel.add(form, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);

        // Cargar datos
        cargarTablaProveedores();

        btnGuardar.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            String tel = txtTelefono.getText().trim();
            String correo = txtCorreo.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El nombre es obligatorio");
                return;
            }
            try (Connection cn = bdCone.conectar();
                 PreparedStatement ps = cn.prepareStatement("INSERT INTO proveedores (nombre, telefono, correo) VALUES (?,?,?)")) {
                ps.setString(1, nombre);
                ps.setString(2, tel);
                ps.setString(3, correo);
                ps.executeUpdate();
                cargarTablaProveedores();
                limpiar(txtId, txtNombre, txtTelefono, txtCorreo);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnActualizar.addActionListener(e -> {
            if (txtId.getText().isEmpty()) return;
            try (Connection cn = bdCone.conectar();
                 PreparedStatement ps = cn.prepareStatement("UPDATE proveedores SET nombre=?, telefono=?, correo=? WHERE id=?")) {
                ps.setString(1, txtNombre.getText());
                ps.setString(2, txtTelefono.getText());
                ps.setString(3, txtCorreo.getText());
                ps.setInt(4, Integer.parseInt(txtId.getText()));
                ps.executeUpdate();
                cargarTablaProveedores();
                limpiar(txtId, txtNombre, txtTelefono, txtCorreo);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnEliminar.addActionListener(e -> {
            if (txtId.getText().isEmpty()) return;
            int id = Integer.parseInt(txtId.getText());
            int conf = JOptionPane.showConfirmDialog(this, "¿Eliminar proveedor " + id + "?");
            if (conf != JOptionPane.YES_OPTION) return;
            try (Connection cn = bdCone.conectar();
                 PreparedStatement ps = cn.prepareStatement("DELETE FROM proveedores WHERE id=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
                cargarTablaProveedores();
                limpiar(txtId, txtNombre, txtTelefono, txtCorreo);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnLimpiar.addActionListener(e -> limpiar(txtId, txtNombre, txtTelefono, txtCorreo));

        tabla.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tabla.getSelectedRow();
                txtId.setText(modeloProv.getValueAt(fila, 0).toString());
                txtNombre.setText(modeloProv.getValueAt(fila, 1).toString());
                txtTelefono.setText(modeloProv.getValueAt(fila, 2).toString());
                txtCorreo.setText(modeloProv.getValueAt(fila, 3).toString());
            }
        });

        return panel;
    }

    private void cargarTablaProveedores() {
        modeloProv.setRowCount(0);
        try (Connection cn = bdCone.conectar();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM proveedores")) {
            while (rs.next()) {
                modeloProv.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getString("correo")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar proveedores: " + e.getMessage());
        }
    }

    // PANEL PRODUCTOS
    private JPanel crearPanelProductos() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel form = new JPanel(new GridLayout(5,2,5,5));

        JTextField txtId = new JTextField(); txtId.setEditable(false);
        JTextField txtNombre = new JTextField();
        JTextField txtPrecio = new JTextField();
        JTextField txtCantidad = new JTextField();
        JButton btnGuardar = new JButton("Guardar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        form.add(new JLabel("ID:")); form.add(txtId);
        form.add(new JLabel("Nombre:")); form.add(txtNombre);
        form.add(new JLabel("Precio:")); form.add(txtPrecio);
        form.add(new JLabel("Cantidad:")); form.add(txtCantidad);

        JPanel botones = new JPanel();
        botones.add(btnGuardar); botones.add(btnActualizar);
        botones.add(btnEliminar); botones.add(btnLimpiar);
        form.add(botones);

        modeloProd = new DefaultTableModel(new String[]{"ID","Nombre","Precio","Cantidad"},0);
        JTable tabla = new JTable(modeloProd);
        JScrollPane scroll = new JScrollPane(tabla);

        panel.add(form, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);

        cargarTablaProductos();

        btnGuardar.addActionListener(e -> {
            try (Connection cn = bdCone.conectar();
                 PreparedStatement ps = cn.prepareStatement("INSERT INTO productos (nombre, precio, cantidad) VALUES (?,?,?)")) {
                ps.setString(1, txtNombre.getText());
                ps.setDouble(2, Double.parseDouble(txtPrecio.getText()));
                ps.setInt(3, Integer.parseInt(txtCantidad.getText()));
                ps.executeUpdate();
                cargarTablaProductos();
                limpiar(txtId, txtNombre, txtPrecio, txtCantidad);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnActualizar.addActionListener(e -> {
            if (txtId.getText().isEmpty()) return;
            try (Connection cn = bdCone.conectar();
                 PreparedStatement ps = cn.prepareStatement("UPDATE productos SET nombre=?, precio=?, cantidad=? WHERE id=?")) {
                ps.setString(1, txtNombre.getText());
                ps.setDouble(2, Double.parseDouble(txtPrecio.getText()));
                ps.setInt(3, Integer.parseInt(txtCantidad.getText()));
                ps.setInt(4, Integer.parseInt(txtId.getText()));
                ps.executeUpdate();
                cargarTablaProductos();
                limpiar(txtId, txtNombre, txtPrecio, txtCantidad);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnEliminar.addActionListener(e -> {
            if (txtId.getText().isEmpty()) return;
            try (Connection cn = bdCone.conectar();
                 PreparedStatement ps = cn.prepareStatement("DELETE FROM productos WHERE id=?")) {
                ps.setInt(1, Integer.parseInt(txtId.getText()));
                ps.executeUpdate();
                cargarTablaProductos();
                limpiar(txtId, txtNombre, txtPrecio, txtCantidad);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        btnLimpiar.addActionListener(e -> limpiar(txtId, txtNombre, txtPrecio, txtCantidad));

        tabla.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tabla.getSelectedRow();
                txtId.setText(modeloProd.getValueAt(fila, 0).toString());
                txtNombre.setText(modeloProd.getValueAt(fila, 1).toString());
                txtPrecio.setText(modeloProd.getValueAt(fila, 2).toString());
                txtCantidad.setText(modeloProd.getValueAt(fila, 3).toString());
            }
        });

        return panel;
    }

    private void cargarTablaProductos() {
        modeloProd.setRowCount(0);
        try (Connection cn = bdCone.conectar();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM productos")) {
            while (rs.next()) {
                modeloProd.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getDouble("precio"),
                    rs.getInt("cantidad")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e.getMessage());
        }
    }

    //PANEL VENTAS
    private JPanel crearPanelVentas() {
    JPanel panel = new JPanel(new BorderLayout());
    JPanel form = new JPanel(new GridLayout(5, 2, 5, 5));

    JComboBox<String> comboProducto = new JComboBox<>();
    JTextField txtIdVenta = new JTextField(); txtIdVenta.setEditable(false);
    JTextField txtCantidad = new JTextField();
    JTextField txtTotal = new JTextField(); txtTotal.setEditable(false);

    JButton btnCalcular = new JButton("Calcular total");
    JButton btnGuardar = new JButton("Guardar venta");
    JButton btnEliminar = new JButton("Eliminar venta");
    JButton btnLimpiar = new JButton("Limpiar");

    // Cargar productos al combo
    cargarProductosEnCombo(comboProducto);

    form.add(new JLabel("ID venta:")); form.add(txtIdVenta);
    form.add(new JLabel("Producto:")); form.add(comboProducto);
    form.add(new JLabel("Cantidad:")); form.add(txtCantidad);
    form.add(new JLabel("Total:")); form.add(txtTotal);
    form.add(btnCalcular); form.add(btnGuardar);

    JPanel botones = new JPanel();
    botones.add(btnEliminar); botones.add(btnLimpiar);
    form.add(botones);

    modeloVentas = new DefaultTableModel(new String[]{"ID", "Producto", "Cantidad", "Total", "Fecha"}, 0);
    JTable tabla = new JTable(modeloVentas);
    JScrollPane scroll = new JScrollPane(tabla);

    panel.add(form, BorderLayout.NORTH);
    panel.add(scroll, BorderLayout.CENTER);

    cargarTablaVentas();

    // --- Eventos ---
    btnCalcular.addActionListener(e -> {
        String prod = (String) comboProducto.getSelectedItem();
        String cantidadText = txtCantidad.getText().trim();
        if (prod == null || cantidadText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto y cantidad.");
            return;
        }
        try (Connection cn = bdCone.conectar();
             PreparedStatement ps = cn.prepareStatement("SELECT precio FROM productos WHERE nombre = ?")) {
            ps.setString(1, prod);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                double precio = rs.getDouble("precio");
                int cantidad = Integer.parseInt(cantidadText);
                double total = precio * cantidad;
                txtTotal.setText(String.valueOf(total));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al calcular total: " + ex.getMessage());
        }
    });

    btnGuardar.addActionListener(e -> {
        if (txtCantidad.getText().isEmpty() || txtTotal.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Calcule el total antes de guardar.");
            return;
        }
        try (Connection cn = bdCone.conectar()) {
            cn.setAutoCommit(false);
            // Insertar venta
            PreparedStatement ps = cn.prepareStatement(
                    "INSERT INTO ventas (producto_id, cantidad, total) VALUES ((SELECT id FROM productos WHERE nombre=?), ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, (String) comboProducto.getSelectedItem());
            ps.setInt(2, Integer.parseInt(txtCantidad.getText()));
            ps.setDouble(3, Double.parseDouble(txtTotal.getText()));
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            int ventaId = 0;
            if (rs.next()) ventaId = rs.getInt(1);

            // Insertar factura asociada
            PreparedStatement ps2 = cn.prepareStatement("INSERT INTO facturas (venta_id) VALUES (?)");
            ps2.setInt(1, ventaId);
            ps2.executeUpdate();

            cn.commit();
            JOptionPane.showMessageDialog(this, "Venta y factura guardadas correctamente.");
            cargarTablaVentas();
            cargarTablaFacturas();
            limpiar(txtIdVenta, txtCantidad, txtTotal);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar venta: " + ex.getMessage());
        }
    });

    btnEliminar.addActionListener(e -> {
        if (txtIdVenta.getText().isEmpty()) return;
        int id = Integer.parseInt(txtIdVenta.getText());
        int conf = JOptionPane.showConfirmDialog(this, "¿Eliminar venta " + id + "?");
        if (conf != JOptionPane.YES_OPTION) return;
        try (Connection cn = bdCone.conectar()) {
            PreparedStatement ps = cn.prepareStatement("DELETE FROM ventas WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
            cargarTablaVentas();
            cargarTablaFacturas();
            limpiar(txtIdVenta, txtCantidad, txtTotal);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + ex.getMessage());
        }
    });
    btnLimpiar.addActionListener(e -> limpiar(txtIdVenta, txtCantidad, txtTotal));
    tabla.addMouseListener(new MouseAdapter() {
        public void mouseClicked(MouseEvent e) {
            int fila = tabla.getSelectedRow();
            txtIdVenta.setText(modeloVentas.getValueAt(fila, 0).toString());
            comboProducto.setSelectedItem(modeloVentas.getValueAt(fila, 1).toString());
            txtCantidad.setText(modeloVentas.getValueAt(fila, 2).toString());
            txtTotal.setText(modeloVentas.getValueAt(fila, 3).toString());
        }
    });
    return panel;
}
private void cargarProductosEnCombo(JComboBox<String> combo) {
    combo.removeAllItems();
    try (Connection cn = bdCone.conectar();
         Statement st = cn.createStatement();
         ResultSet rs = st.executeQuery("SELECT nombre FROM productos")) {
        while (rs.next()) combo.addItem(rs.getString("nombre"));
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e.getMessage());
    }
}

private void cargarTablaVentas() {
    modeloVentas.setRowCount(0);
    try (Connection cn = bdCone.conectar();
         Statement st = cn.createStatement();
         ResultSet rs = st.executeQuery(
                 "SELECT v.id, p.nombre AS producto, v.cantidad, v.total, v.fecha FROM ventas v LEFT JOIN productos p ON v.producto_id = p.id")) {
        while (rs.next()) {
            modeloVentas.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("producto"),
                    rs.getInt("cantidad"),
                    rs.getDouble("total"),
                    rs.getString("fecha")
            });
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar ventas: " + e.getMessage());
    }
}

    //PANEL FACTURAS
    private JPanel crearPanelFacturas() {
    JPanel panel = new JPanel(new BorderLayout());
    modeloFact = new DefaultTableModel(new String[]{"ID", "Venta ID", "Fecha"}, 0);
    JTable tabla = new JTable(modeloFact);
    JScrollPane scroll = new JScrollPane(tabla);
    panel.add(scroll, BorderLayout.CENTER);
    cargarTablaFacturas();
    return panel;
}

private void cargarTablaFacturas() {
    modeloFact.setRowCount(0);
    try (Connection cn = bdCone.conectar();
         Statement st = cn.createStatement();
         ResultSet rs = st.executeQuery("SELECT id, venta_id, fecha FROM facturas ORDER BY id DESC")) {
        while (rs.next()) {
            modeloFact.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getInt("venta_id"),
                    rs.getString("fecha")
            });
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error al cargar facturas: " + e.getMessage());
    }
}

    // UTILIDADES
    private void limpiar(JTextField... campos) {
        for (JTextField c : campos) c.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ConeBD().setVisible(true));
    }
}